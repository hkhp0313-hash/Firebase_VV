import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { Shield, Mail, AlertCircle, Loader2, CheckCircle2, ArrowLeft, Phone } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";

const otpSchema = z.object({
  otp: z.string().length(6, "OTP must be 6 digits"),
});

type OTPFormValues = z.infer<typeof otpSchema>;

const VerifyOTP = () => {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [searchParams] = useSearchParams();
  const email = searchParams.get("email") || "";
  const phone = searchParams.get("phone") || "";
  const method = searchParams.get("method") || "email";
  const { verifyOTP, verifySMSOTP, resendOTP, resendSMSOTP } = useAuth();
  const navigate = useNavigate();

  const form = useForm<OTPFormValues>({
    resolver: zodResolver(otpSchema),
    defaultValues: {
      otp: "",
    },
  });

  useEffect(() => {
    if (method === "email" && !email) {
      navigate("/signup");
    } else if (method === "sms" && !phone) {
      navigate("/signup");
    }
  }, [email, phone, method, navigate]);

  const onSubmit = async (values: OTPFormValues) => {
    if (method === "email" && !email) {
      setError("Email is required");
      return;
    }
    if (method === "sms" && !phone) {
      setError("Phone number is required");
      return;
    }

    setError(null);
    setLoading(true);
    
    try {
      let error;
      if (method === "sms") {
        const result = await verifySMSOTP(phone, values.otp);
        error = result.error;
      } else {
        const result = await verifyOTP(email, values.otp);
        error = result.error;
      }
      
      if (error) {
        setError(error.message || "Invalid OTP. Please try again.");
        form.reset();
      } else {
        setSuccess(true);
        toast.success("Account verified successfully!", {
          description: "Your account has been verified. Redirecting to sign in...",
        });
        setTimeout(() => {
          navigate("/signin");
        }, 2000);
      }
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred");
      form.reset();
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async () => {
    if (method === "email" && !email) {
      setError("Email is required");
      return;
    }
    if (method === "sms" && !phone) {
      setError("Phone number is required");
      return;
    }

    setError(null);
    setResending(true);
    
    try {
      let error;
      if (method === "sms") {
        const result = await resendSMSOTP(phone);
        error = result.error;
        if (!error) {
          toast.success("OTP resent!", {
            description: "A new OTP has been sent to your phone via SMS.",
          });
        }
      } else {
        const result = await resendOTP(email);
        error = result.error;
        if (!error) {
          toast.success("OTP resent!", {
            description: "A new OTP has been sent to your email.",
          });
        }
      }
      
      if (error) {
        setError(error.message || "Failed to resend OTP. Please try again.");
      } else {
        form.reset();
      }
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred");
    } finally {
      setResending(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 bg-gradient-card backdrop-blur-sm border border-border/50 shadow-glass text-center">
          <div className="flex flex-col items-center">
            <div className="p-3 rounded-full bg-success/20 mb-4">
              <CheckCircle2 className="h-8 w-8 text-success" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Account Verified!</h1>
            <p className="text-muted-foreground mb-4">
              Your account has been successfully verified. Redirecting to sign in...
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 bg-gradient-card backdrop-blur-sm border border-border/50 shadow-glass">
        <div className="flex flex-col items-center mb-8">
          <div className="p-3 rounded-full bg-gradient-medical mb-4">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-medical bg-clip-text text-transparent mb-2">
            Verify Your Account
          </h1>
          <p className="text-muted-foreground text-center">
            Enter the 6-digit OTP sent to your {method === "sms" ? "phone" : "email"}
          </p>
          {method === "sms" && phone && (
            <p className="text-sm text-primary mt-2 font-medium">
              {phone}
            </p>
          )}
          {method === "email" && email && (
            <p className="text-sm text-primary mt-2 font-medium">
              {email}
            </p>
          )}
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="otp"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Enter OTP</FormLabel>
                  <FormControl>
                    <div className="flex justify-center">
                      <InputOTP
                        maxLength={6}
                        {...field}
                        disabled={loading}
                      >
                        <InputOTPGroup>
                          <InputOTPSlot index={0} />
                          <InputOTPSlot index={1} />
                          <InputOTPSlot index={2} />
                          <InputOTPSlot index={3} />
                          <InputOTPSlot index={4} />
                          <InputOTPSlot index={5} />
                        </InputOTPGroup>
                      </InputOTP>
                    </div>
                  </FormControl>
                  <FormDescription className="text-center">
                    Check your {method === "sms" ? "phone (SMS)" : "email"} for the verification code
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full bg-gradient-medical hover:opacity-90 shadow-medical"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : (
                "Verify Account"
              )}
            </Button>
          </form>
        </Form>

        <div className="mt-6 space-y-3">
          <Button
            variant="outline"
            className="w-full"
            onClick={handleResendOTP}
            disabled={resending || loading}
          >
            {resending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Resending...
              </>
            ) : (
              <>
                {method === "sms" ? (
                  <Phone className="mr-2 h-4 w-4" />
                ) : (
                  <Mail className="mr-2 h-4 w-4" />
                )}
                Resend OTP
              </>
            )}
          </Button>

          <Button
            variant="ghost"
            className="w-full"
            onClick={() => navigate("/signup")}
            disabled={loading}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Sign Up
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default VerifyOTP;

