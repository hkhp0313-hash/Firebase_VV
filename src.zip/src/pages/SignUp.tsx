import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Shield, Mail, Lock, User, AlertCircle, Loader2, Phone } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Country codes list
const countryCodes = [
  { code: "+1", country: "US", name: "United States" },
  { code: "+1", country: "CA", name: "Canada" },
  { code: "+44", country: "GB", name: "United Kingdom" },
  { code: "+91", country: "IN", name: "India" },
  { code: "+86", country: "CN", name: "China" },
  { code: "+81", country: "JP", name: "Japan" },
  { code: "+49", country: "DE", name: "Germany" },
  { code: "+33", country: "FR", name: "France" },
  { code: "+39", country: "IT", name: "Italy" },
  { code: "+34", country: "ES", name: "Spain" },
  { code: "+61", country: "AU", name: "Australia" },
  { code: "+55", country: "BR", name: "Brazil" },
  { code: "+7", country: "RU", name: "Russia" },
  { code: "+82", country: "KR", name: "South Korea" },
  { code: "+52", country: "MX", name: "Mexico" },
  { code: "+31", country: "NL", name: "Netherlands" },
  { code: "+46", country: "SE", name: "Sweden" },
  { code: "+47", country: "NO", name: "Norway" },
  { code: "+41", country: "CH", name: "Switzerland" },
  { code: "+32", country: "BE", name: "Belgium" },
  { code: "+43", country: "AT", name: "Austria" },
  { code: "+45", country: "DK", name: "Denmark" },
  { code: "+358", country: "FI", name: "Finland" },
  { code: "+353", country: "IE", name: "Ireland" },
  { code: "+351", country: "PT", name: "Portugal" },
  { code: "+30", country: "GR", name: "Greece" },
  { code: "+48", country: "PL", name: "Poland" },
  { code: "+420", country: "CZ", name: "Czech Republic" },
  { code: "+36", country: "HU", name: "Hungary" },
  { code: "+40", country: "RO", name: "Romania" },
  { code: "+65", country: "SG", name: "Singapore" },
  { code: "+60", country: "MY", name: "Malaysia" },
  { code: "+66", country: "TH", name: "Thailand" },
  { code: "+84", country: "VN", name: "Vietnam" },
  { code: "+62", country: "ID", name: "Indonesia" },
  { code: "+63", country: "PH", name: "Philippines" },
  { code: "+64", country: "NZ", name: "New Zealand" },
  { code: "+27", country: "ZA", name: "South Africa" },
  { code: "+20", country: "EG", name: "Egypt" },
  { code: "+971", country: "AE", name: "UAE" },
  { code: "+966", country: "SA", name: "Saudi Arabia" },
  { code: "+972", country: "IL", name: "Israel" },
  { code: "+90", country: "TR", name: "Turkey" },
  { code: "+92", country: "PK", name: "Pakistan" },
  { code: "+880", country: "BD", name: "Bangladesh" },
  { code: "+94", country: "LK", name: "Sri Lanka" },
  { code: "+95", country: "MM", name: "Myanmar" },
  { code: "+234", country: "NG", name: "Nigeria" },
  { code: "+254", country: "KE", name: "Kenya" },
  { code: "+233", country: "GH", name: "Ghana" },
].sort((a, b) => a.name.localeCompare(b.name));

const signUpSchema = z.object({
  fullName: z.string().min(2, "Full name must be at least 2 characters").max(50, "Full name is too long"),
  email: z.string().email("Please enter a valid email address").min(1, "Email is required"),
  countryCode: z.string().min(1, "Country code is required"),
  mobileNumber: z.string()
    .min(7, "Mobile number must be at least 7 digits")
    .regex(/^[0-9\s\-()]+$/, "Please enter a valid mobile number (digits only)"),
  password: z
    .string()
    .min(6, "Password must be at least 6 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type SignUpFormValues = z.infer<typeof signUpSchema>;

const SignUp = () => {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [otpMethod, setOtpMethod] = useState<"email" | "sms">("email");
  const { signUp, sendSMSOTP } = useAuth();
  const navigate = useNavigate();

  const form = useForm<SignUpFormValues>({
    resolver: zodResolver(signUpSchema),
    defaultValues: {
      fullName: "",
      email: "",
      countryCode: "+1",
      mobileNumber: "",
      password: "",
      confirmPassword: "",
    },
  });

  const onSubmit = async (values: SignUpFormValues) => {
    setError(null);
    setLoading(true);
    
    // Combine country code and mobile number
    const fullMobileNumber = `${values.countryCode}${values.mobileNumber.replace(/\s|-|\(|\)/g, "")}`;
    
    try {
      // Always create the account first
      const { error: signUpError, data } = await signUp(
        values.email,
        values.password,
        values.fullName,
        fullMobileNumber
      );
      
      if (signUpError) {
        setError(signUpError.message || "Failed to create account. Please try again.");
        setLoading(false);
        return;
      }

      if (otpMethod === "sms") {
        // Send SMS OTP for phone verification
        const { error: smsError } = await sendSMSOTP(fullMobileNumber);
        
        if (smsError) {
          setError(smsError.message || "Failed to send SMS OTP. Please try again.");
        } else {
          // Navigate to OTP verification page with phone
          navigate(`/verify-otp?phone=${encodeURIComponent(fullMobileNumber)}&method=sms&email=${encodeURIComponent(values.email)}`);
        }
      } else {
        // Email OTP flow - OTP is automatically sent via email during signup
        // Navigate to OTP verification page with email
        navigate(`/verify-otp?email=${encodeURIComponent(values.email)}&method=email`);
      }
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 bg-gradient-card backdrop-blur-sm border border-border/50 shadow-glass">
        <div className="flex flex-col items-center mb-8">
          <div className="p-3 rounded-full bg-gradient-medical mb-4">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-medical bg-clip-text text-transparent mb-2">
            Create Account
          </h1>
          <p className="text-muted-foreground text-center">
            Join SafeVitals to manage your health
          </p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        {...field}
                        type="text"
                        placeholder="John Doe"
                        className="pl-10"
                        disabled={loading}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        {...field}
                        type="email"
                        placeholder="you@example.com"
                        className="pl-10"
                        disabled={loading}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <FormLabel>Mobile Number</FormLabel>
              <div className="flex gap-2">
                <FormField
                  control={form.control}
                  name="countryCode"
                  render={({ field }) => (
                    <FormItem className="w-[140px] flex-shrink-0">
                      <FormControl>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          disabled={loading}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Code" />
                          </SelectTrigger>
                          <SelectContent className="max-h-[300px]">
                            {countryCodes.map((country) => (
                              <SelectItem key={`${country.code}-${country.country}`} value={country.code}>
                                <div className="flex items-center gap-2">
                                  <span className="font-medium">{country.code}</span>
                                  <span className="text-muted-foreground text-xs">{country.country}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="mobileNumber"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormControl>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            {...field}
                            type="tel"
                            placeholder="555 123 4567"
                            className="pl-10"
                            disabled={loading}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormDescription className="text-xs">
                Enter your mobile number without the country code
              </FormDescription>
            </div>

            {/* OTP Method Selection */}
            <div className="space-y-2">
              <FormLabel>Verification Method</FormLabel>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={otpMethod === "email" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => setOtpMethod("email")}
                  disabled={loading}
                >
                  <Mail className="h-4 w-4 mr-2" />
                  Email OTP
                </Button>
                <Button
                  type="button"
                  variant={otpMethod === "sms" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => setOtpMethod("sms")}
                  disabled={loading}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  SMS OTP
                </Button>
              </div>
              <FormDescription className="text-xs">
                Choose how you want to receive your verification code
              </FormDescription>
            </div>

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        {...field}
                        type="password"
                        placeholder="Create a strong password"
                        className="pl-10"
                        disabled={loading}
                      />
                    </div>
                  </FormControl>
                  <FormDescription className="text-xs">
                    Must be at least 6 characters with uppercase, lowercase, and number
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        {...field}
                        type="password"
                        placeholder="Confirm your password"
                        className="pl-10"
                        disabled={loading}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full bg-gradient-medical hover:opacity-90 shadow-medical"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating account...
                </>
              ) : (
                "Create Account"
              )}
            </Button>
          </form>
        </Form>

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link
              to="/signin"
              className="text-primary hover:underline font-medium"
            >
              Sign in
            </Link>
          </p>
        </div>
      </Card>
    </div>
  );
};

export default SignUp;

