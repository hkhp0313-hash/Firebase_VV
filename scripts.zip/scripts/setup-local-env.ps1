# PowerShell script to update .env file for local Supabase development
# Usage: .\scripts\setup-local-env.ps1

Write-Host "Setting up local environment variables..." -ForegroundColor Cyan
Write-Host ""

# Get Supabase status to extract URLs and keys
$statusOutput = npx supabase status --output json 2>&1 | Out-String

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Supabase is not running!" -ForegroundColor Red
    Write-Host "Please run 'npx supabase start' first" -ForegroundColor Yellow
    exit 1
}

# Parse the status output
try {
    $status = $statusOutput | ConvertFrom-Json
    
    $apiUrl = $status.APIUrl
    $anonKey = $status.anonKey
    
    Write-Host "Found Supabase local configuration:" -ForegroundColor Green
    Write-Host "  API URL: $apiUrl" -ForegroundColor White
    Write-Host "  Anon Key: $anonKey" -ForegroundColor White
    Write-Host ""
    
    # Read current .env file
    $envPath = ".env"
    $envLocalPath = ".env.local"
    
    if (Test-Path $envPath) {
        $envContent = Get-Content $envPath -Raw
        
        # Update or add VITE_SUPABASE_URL
        if ($envContent -match "VITE_SUPABASE_URL=.*") {
            $envContent = $envContent -replace "VITE_SUPABASE_URL=.*", "VITE_SUPABASE_URL=$apiUrl"
            Write-Host "✓ Updated VITE_SUPABASE_URL" -ForegroundColor Green
        } else {
            $envContent += "`nVITE_SUPABASE_URL=$apiUrl"
            Write-Host "✓ Added VITE_SUPABASE_URL" -ForegroundColor Green
        }
        
        # Update or add VITE_SUPABASE_PUBLISHABLE_KEY
        if ($envContent -match "VITE_SUPABASE_PUBLISHABLE_KEY=.*") {
            $envContent = $envContent -replace "VITE_SUPABASE_PUBLISHABLE_KEY=.*", "VITE_SUPABASE_PUBLISHABLE_KEY=$anonKey"
            Write-Host "✓ Updated VITE_SUPABASE_PUBLISHABLE_KEY" -ForegroundColor Green
        } else {
            $envContent += "`nVITE_SUPABASE_PUBLISHABLE_KEY=$anonKey"
            Write-Host "✓ Added VITE_SUPABASE_PUBLISHABLE_KEY" -ForegroundColor Green
        }
        
        # Backup original .env
        Copy-Item $envPath "$envPath.backup" -Force
        Write-Host "✓ Created backup: .env.backup" -ForegroundColor Gray
        
        # Write updated content
        Set-Content -Path $envPath -Value $envContent.Trim()
        
        Write-Host ""
        Write-Host "✓ Environment variables updated successfully!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Your .env file now points to local Supabase." -ForegroundColor Cyan
        Write-Host "To restore cloud settings, restore from .env.backup" -ForegroundColor Gray
    } else {
        Write-Host "✗ .env file not found!" -ForegroundColor Red
        Write-Host "Creating new .env file..." -ForegroundColor Yellow
        
        $newEnvContent = @"
VITE_SUPABASE_URL=$apiUrl
VITE_SUPABASE_PUBLISHABLE_KEY=$anonKey
"@
        Set-Content -Path $envPath -Value $newEnvContent
        Write-Host "✓ Created .env file" -ForegroundColor Green
    }
    
} catch {
    Write-Host "✗ Failed to parse Supabase status" -ForegroundColor Red
    Write-Host "Error: $_" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "You can manually update .env with:" -ForegroundColor Cyan
    Write-Host "  VITE_SUPABASE_URL=http://localhost:54321" -ForegroundColor White
    Write-Host "  VITE_SUPABASE_PUBLISHABLE_KEY=<from 'npx supabase status'>" -ForegroundColor White
    exit 1
}

