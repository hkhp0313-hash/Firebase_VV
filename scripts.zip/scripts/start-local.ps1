# PowerShell script to start local Supabase development environment
# Usage: .\scripts\start-local.ps1

Write-Host "Starting Local Supabase Development Environment..." -ForegroundColor Cyan
Write-Host ""

# Check if Docker is running
Write-Host "Checking Docker Desktop..." -ForegroundColor Yellow
try {
    docker ps | Out-Null
    Write-Host "✓ Docker Desktop is running" -ForegroundColor Green
} catch {
    Write-Host "✗ Docker Desktop is not running!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install and start Docker Desktop first:" -ForegroundColor Yellow
    Write-Host "1. Download: https://docs.docker.com/desktop/install/windows-install/" -ForegroundColor White
    Write-Host "2. Install Docker Desktop" -ForegroundColor White
    Write-Host "3. Start Docker Desktop and ensure it's running" -ForegroundColor White
    Write-Host "4. Run this script again" -ForegroundColor White
    exit 1
}

Write-Host ""

# Start Supabase
Write-Host "Starting Supabase services..." -ForegroundColor Yellow
Write-Host "This may take a few minutes on first run as it downloads Docker images." -ForegroundColor Gray
Write-Host ""

npx supabase start

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✓ Supabase is running locally!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Cyan
    Write-Host "1. Copy the API URL and anon key from above" -ForegroundColor White
    Write-Host "2. Update your .env file with:" -ForegroundColor White
    Write-Host "   VITE_SUPABASE_URL=http://localhost:54321" -ForegroundColor Gray
    Write-Host "   VITE_SUPABASE_PUBLISHABLE_KEY=<anon key from output>" -ForegroundColor Gray
    Write-Host "3. Visit Supabase Studio: http://localhost:54323" -ForegroundColor White
    Write-Host "4. Restart your frontend dev server" -ForegroundColor White
} else {
    Write-Host ""
    Write-Host "✗ Failed to start Supabase" -ForegroundColor Red
    Write-Host "Check the error messages above for details" -ForegroundColor Yellow
    exit 1
}

