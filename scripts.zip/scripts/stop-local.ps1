# PowerShell script to stop local Supabase development environment
# Usage: .\scripts\stop-local.ps1

Write-Host "Stopping Local Supabase Services..." -ForegroundColor Cyan
Write-Host ""

npx supabase stop

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✓ Supabase services stopped" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "✗ Failed to stop Supabase" -ForegroundColor Red
    exit 1
}

